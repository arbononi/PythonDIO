# meupacote

Description. Apenas um estudo sobre criação e distribuição de pacotes

## Installation

Não possui instalação


## Usage
Sem uso

## Author
André Rogério

